package projgramozok;

public interface Rajzolhato {
	/**
	 * Rajzol�f�ggv�ny
	 * @param xpos - az x poz�ci�ja az objektumnak
	 * @param ypos - az y poz�ci�
	 */
	public void rajzol(int xpos, int ypos);
}
